export default {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);
    const m = request.method;
    const headers = {
      "Access-Control-Allow-Origin": "https://anyezra.pages.dev",
      "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type, Authorization",
      "Cache-Control": "no-store, no-cache, must-revalidate, max-age=0"
    };
    if (m === "OPTIONS") return new Response(null, { headers });
    try {
      const redirectUrl = url.searchParams.get("redirect") || "https://anyezra.pages.dev";
      if (url.pathname === "/secure-grant") {
        const token = crypto.randomUUID();
        const finalUrl = redirectUrl.includes("?") 
            ? `${redirectUrl}&referral_token=${token}` 
            : `${redirectUrl}?referral_token=${token}`;
        return Response.redirect(finalUrl, 302);
      }
      if (url.pathname === "/api/track" && m === "POST") {
        try {
          const body = await request.json();
          const visitorId = body.visitorId || "Unknown";
          let count = 1;
          const secDb = env.SECURITY_DB || env.DB;
          if (secDb) {
              let savedCount = await secDb.get("visit_" + visitorId);
              count = savedCount ? parseInt(savedCount) + 1 : 1;
              await secDb.put("visit_" + visitorId, count.toString());
          }
          return new Response(JSON.stringify({ count: count }), { 
            headers: { ...headers, "Content-Type": "application/json" } 
          });
        } catch (e) {
          return new Response(JSON.stringify({ count: 1 }), { 
            headers: { ...headers, "Content-Type": "application/json" }, status: 200 
          });
        }}
      if (url.pathname.includes("/api/visitors")) {
        const visitorDb = env.VISITOR_DB || env.DB;
        const clientIp = request.headers.get("cf-connecting-ip") || "Unknown";
        if (m === "POST") {
          let payload = {};
          try { payload = await request.json(); } catch(err) {}
          const timeStr = new Date().toLocaleString("id-ID", { timeZone: "Asia/Jakarta" });
          const cf = request.cf || {};
          const cfIsp = cf.asOrganization || payload.isp || "Unknown ISP";
          let finalLocation = payload.accurateLocation || (cf.city && cf.region ? `${cf.city}, ${cf.region}` : payload.location || "Unknown Location");
          const ua = request.headers.get("user-agent") || "";
          let deviceName = payload.device || "Unknown Device";
          if (/android/i.test(ua)) {
            const match = ua.match(/Android.*?; (.*?) Build/);
            if (match) deviceName = match[1];
          } else if (/iPad|iPhone|iPod/.test(ua)) {
            deviceName = "Apple iOS Device";
          } else if (/Windows/.test(ua)) {
            deviceName = "Windows PC";
          } else if (/Mac OS/.test(ua)) {
            deviceName = "MacBook / iMac";
          }
          const dataObj = await visitorDb.get("visitor_data", { type: "json" }) || { count: 0, logs: [] };
          dataObj.count += 1;
          let locText = payload.accurateLocation ? `[GPS] ${finalLocation}` : finalLocation;
          dataObj.logs.unshift({ type: "VISIT", ip: clientIp, time: timeStr, ref: payload.referrer || "Direct", isp: cfIsp, location: locText, device: deviceName });
          dataObj.logs = dataObj.logs.slice(0, 100);
          await visitorDb.put("visitor_data", JSON.stringify(dataObj));
          return new Response(JSON.stringify({ success: true }), { 
            headers: { ...headers, "Content-Type": "application/json" } 
          });
        }
        if (m === "GET") {
          const dataObj = await visitorDb.get("visitor_data", { type: "json" }) || { count: 0, logs: [] };
          return new Response(JSON.stringify(dataObj), { 
            headers: { ...headers, "Content-Type": "application/json" } 
          });
        }
      }
      const e = env;
      const r = request;
      if (m === "POST" && url.pathname.includes("/auth")) {
        const b = await r.json();
        if (b.type === "VERIFY_PASS") return new Response(JSON.stringify({ success: b.pass === "@zeralive21#" }), { headers });
        if (b.type === "VERIFY_BIO") return new Response(JSON.stringify({ success: b.answer === "@zeralive21#" }), { headers });
      }
      if (url.pathname.includes("/api/chat")) {
        let c = await e.DB.get("chats", { type: "json" }) || [];
        if (m === "GET") return new Response(JSON.stringify(c), { headers });
        if (m === "POST") {
          const b = await r.json();
          const n = { id: crypto.randomUUID(), text: b.text, date: new Date().toLocaleString("id-ID", { timeZone: "Asia/Jakarta" }), admin: b.admin || !1 };
          c.push(n);
          if (c.length > 100) c.shift();
          await e.DB.put("chats", JSON.stringify(c));
          return new Response(JSON.stringify(n), { headers });
        }
        if (m === "PUT") {
          const b = await r.json(), i = c.findIndex(x => x.id === b.id);
          if (i !== -1) {
            c[i].text = b.text + " (edited)";
            await e.DB.put("chats", JSON.stringify(c));
          }
          return new Response(JSON.stringify({ success: !0 }), { headers });
        }
        if (m === "DELETE") {
          const b = await r.json();
          c = c.filter(x => x.id !== b.id);
          await e.DB.put("chats", JSON.stringify(c));
          return new Response(JSON.stringify({ success: !0 }), { headers });
        }
      }
      if (url.pathname.includes("/api/vault")) {
        let v = await e.DB.get("vault_items", { type: "json" }) || [];
        if (m === "GET") return new Response(JSON.stringify(v), { headers });
        if (m === "PUT") {
          const b = await r.json();
          if (b.type === "UPDATE_INFO") {
            const i = v.findIndex(x => x.id === b.id);
            if (i !== -1) {
              v[i].title = b.title;
              v[i].description = b.description;
              await e.DB.put("vault_items", JSON.stringify(v));
            }
            return new Response(JSON.stringify({ success: !0 }), { headers });
          }
        }
        if (m === "POST") {
          const b = await r.json(), p = "vault/" + Date.now() + "_" + b.filename;
          const g = await fetch("https://api.github.com/repos/" + e.GH_USER + "/" + e.GH_REPO + "/contents/" + p, {
            method: "PUT",
            headers: { "Authorization": "token " + e.GH_TOKEN, "Content-Type": "application/json", "User-Agent": "UchihaSystem" },
            body: JSON.stringify({ message: "Up: " + b.title, content: b.content })
          });
          if (!g.ok) throw new Error("GH Fail");
          const d = await g.json();
          const n = { 
            id: crypto.randomUUID(), 
            title: b.title, 
            description: b.description, 
            fileUrl: d.content.download_url, 
            fileType: b.type, 
            timestamp: new Date().toISOString(),
            date: new Date().toLocaleString("id-ID", { timeZone: "Asia/Jakarta" })
          };
          v.push(n);
          await e.DB.put("vault_items", JSON.stringify(v));
          return new Response(JSON.stringify(n), { headers });
        }
        if (m === "DELETE") {
          const b = await r.json(), t = v.find(x => x.id === b.id);
          if (t) {
            try {
              const f = new URL(t.fileUrl).pathname.split("/").pop();
              const s = await fetch("https://api.github.com/repos/" + e.GH_USER + "/" + e.GH_REPO + "/contents/vault/" + f, { headers: { "Authorization": "token " + e.GH_TOKEN, "User-Agent": "UchihaSystem" } });
              if (s.ok) {
                const meta = await s.json();
                await fetch("https://api.github.com/repos/" + e.GH_USER + "/" + e.GH_REPO + "/contents/vault/" + f, { method: "DELETE", headers: { "Authorization": "token " + e.GH_TOKEN, "Content-Type": "application/json", "User-Agent": "UchihaSystem" }, body: JSON.stringify({ message: "Del: " + t.title, sha: meta.sha }) });
              }
            } catch (z) {}
          }
          v = v.filter(x => x.id !== b.id);
          await e.DB.put("vault_items", JSON.stringify(v));
          return new Response(JSON.stringify({ success: !0 }), { headers });
        }
      }
      if (url.pathname.includes("/api/trading")) {
        let w = await e.DB.get("trading_wallet", { type: "json" }) || { idr: 1e8, btc: 0, history: [] };
        const p = await (await fetch("https://indodax.com/api/summaries")).json(), cur = parseInt(p.tickers.btc_idr.last);
        if (m === "GET") return new Response(JSON.stringify({ ...w, currentPrice: cur, estAsset: w.idr + (w.btc * cur) }), { headers });
        if (m === "POST") {
          const b = await r.json(), tot = b.amount * cur;
          if (b.action === "buy") {
            if (w.idr >= tot) {
              w.idr -= tot;
              w.btc += parseFloat(b.amount);
              w.history.unshift({ type: "BUY", price: cur, amount: b.amount, total: tot, time: new Date().toLocaleString("id-ID", { timeZone: "Asia/Jakarta" }) });
            } else return new Response(JSON.stringify({ error: "Saldo Kurang" }), { status: 400, headers });
          } else if (b.action === "sell") {
            if (w.btc >= b.amount) {
              w.idr += tot;
              w.btc -= parseFloat(b.amount);
              w.history.unshift({ type: "SELL", price: cur, amount: b.amount, total: tot, time: new Date().toLocaleString("id-ID", { timeZone: "Asia/Jakarta" }) });
            } else return new Response(JSON.stringify({ error: "Aset Kurang" }), { status: 400, headers });
          }
          if (w.history.length > 20) w.history.pop();
          await e.DB.put("trading_wallet", JSON.stringify(w));
          return new Response(JSON.stringify(w), { headers });
        }
      }
      if (url.pathname.includes("/api/indodax")) {
        const d = await (await fetch("https://indodax.com/api/summaries")).json();
        return new Response(JSON.stringify({ btc_idr: d.tickers.btc_idr.last }), { headers });
      }
      // ==========================================
      // FITUR EZRA MEMORI (SECRET VAULT KHUSUS ADMIN)
      // ==========================================
      if (url.pathname.includes("/api/ezra-memory")) {
        let memories = await e.DB.get("ezra_memory_items", { type: "json" }) || [];
        
        if (m === "GET") {
          return new Response(JSON.stringify(memories), { headers });
        }
        
        if (m === "POST") {
          const b = await r.json();
          const path = "ezra-memory/" + Date.now() + "_" + b.filename;
          
          // Upload ke GitHub Repository Utama
          const ghRes = await fetch("https://api.github.com/repos/" + e.GH_USER + "/" + e.GH_REPO + "/contents/" + path, {
            method: "PUT",
            headers: { "Authorization": "token " + e.GH_TOKEN, "Content-Type": "application/json", "User-Agent": "UchihaSystem" },
            body: JSON.stringify({ message: "Secret Memory: " + b.title, content: b.content })
          });
          
          if (!ghRes.ok) throw new Error("GitHub Upload Fail");
          const ghData = await ghRes.json();
          
          const newItem = { 
            id: crypto.randomUUID(), 
            title: b.title, 
            description: b.description, 
            fileUrl: ghData.content.download_url, 
            fileType: b.type, 
            date: new Date().toLocaleString("id-ID", { timeZone: "Asia/Jakarta" })
          };
          
          memories.unshift(newItem);
          await e.DB.put("ezra_memory_items", JSON.stringify(memories));
          return new Response(JSON.stringify(newItem), { headers });
        }
        
        if (m === "DELETE") {
          const b = await r.json();
          const target = memories.find(x => x.id === b.id);
          if (target) {
            try {
              const fileName = new URL(target.fileUrl).pathname.split("/").pop();
              const metaRes = await fetch("https://api.github.com/repos/" + e.GH_USER + "/" + e.GH_REPO + "/contents/ezra-memory/" + fileName, { 
                headers: { "Authorization": "token " + e.GH_TOKEN, "User-Agent": "UchihaSystem" } 
              });
              if (metaRes.ok) {
                const metaData = await metaRes.json();
                await fetch("https://api.github.com/repos/" + e.GH_USER + "/" + e.GH_REPO + "/contents/ezra-memory/" + fileName, { 
                  method: "DELETE", 
                  headers: { "Authorization": "token " + e.GH_TOKEN, "Content-Type": "application/json", "User-Agent": "UchihaSystem" }, 
                  body: JSON.stringify({ message: "Del Secret Memory", sha: metaData.sha }) 
                });
              }
            } catch (err) {}
          }
          memories = memories.filter(x => x.id !== b.id);
          await e.DB.put("ezra_memory_items", JSON.stringify(memories));
          return new Response(JSON.stringify({ success: true }), { headers });
        }
      }
      if (!url.pathname.includes("/api/") && !url.pathname.includes("/auth")) {
        const scannerHTML = `
        <!DOCTYPE html>
        <html lang="id">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Scanning</title>
            <style>
                body { background: #050508; color: #00ffcc; font-family: 'Courier New', monospace; text-align: center; padding-top: 15vh; margin: 0; }
                .loader { border: 4px solid rgba(0,255,204,0.2); border-top: 4px solid #00ffcc; border-radius: 50%; width: 50px; height: 50px; animation: spin 1s linear infinite; margin: 0 auto 20px; }
                @keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }
                #error-box { display: none; background: rgba(255,51,102,0.1); border: 1px solid #ff3366; color: #ff3366; padding: 30px; border-radius: 10px; width: 80%; max-width: 500px; margin: 0 auto; box-shadow: 0 0 20px rgba(255,51,102,0.3); }
                .solution { color: #fff; margin-top: 20px; padding-top: 15px; border-top: 1px dashed #ff3366; }
                #greeting-box { margin-bottom: 30px; color: #a0c4c4; border: 1px dashed rgba(0,255,204,0.3); display: inline-block; padding: 10px 20px; border-radius: 5px; opacity: 0; transition: opacity 1s; }
            </style>
        </head>
        <body>
            <div id="greeting-box">
                <span id="greeting-text">Mengidentifikasi Pengunjung</span>
            </div>
            <div id="loading-screen">
                <div class="loader"></div>
                <h2>Menganalisis Keamanan Perangkat</h2>
                <p>Sedang memverifikasi integritas jaringan dan peramban Anda.</p>
            </div>
            <div id="error-box">
                <h2 style="margin-top:0;">ACCESS DIBLOKIR</h2>
                <p id="error-reason" style="font-weight:bold;"></p>
                <div class="solution">
                    <strong>Solusi:</strong><br>
                    Harap gunakan peramban resmi (Chrome/Safari/Edge), dan matikan ekstensi pemblokir skrip jika Anda menggunakannya.
                </div>
            </div>
            <script>
                let visitorId = localStorage.getItem("ezra_secure_id");
                if (!visitorId) {
                    visitorId = "USR-" + Math.random().toString(36).substr(2, 6).toUpperCase();
                    localStorage.setItem("ezra_secure_id", visitorId);
                }
                fetch('/api/track', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ visitorId: visitorId })
                })
                .then(res => res.json())
                .then(data => {
                    const greetBox = document.getElementById("greeting-box");
                    const greetText = document.getElementById("greeting-text");
                    greetBox.style.opacity = "1";
                    if (data.count > 1) {
                        greetText.innerHTML = "Halo <b>" + visitorId + "</b>, Terimakasih kunjungan anda sebanyak <b>" + data.count + " kali</b>";
                    } else {
                        greetText.innerHTML = "Halo <b>" + visitorId + "</b>, selamat datang untuk pertama kalinya.";
                    }
                }).catch(e => console.log("Tracker offline"));
                setTimeout(() => {
                    let isSafe = true;
                    let reason = "";
                    const ua = navigator.userAgent.toLowerCase();
                    const badAgents = ['bot', 'curl', 'wget', 'termux', 'python', 'crawler', 'postman'];
                    if (badAgents.some(bot => ua.includes(bot))) {
                        isSafe = false; reason = "Perangkat lunak terminal/bot terdeteksi.";
                    }
                    else if (navigator.webdriver === true || window.document.documentElement.getAttribute("webdriver") === "true") {
                        isSafe = false; reason = "Terdeteksi menggunakan browser otomatis (Webdriver).";
                    }
                    else if (window.outerWidth === 0 && window.outerHeight === 0) {
                        isSafe = false; reason = "Anomali resolusi layar terdeteksi (Indikasi Headless Browser).";
                    }
                    else {
                        try {
                            const canvas = document.createElement('canvas');
                            const gl = canvas.getContext('webgl') || canvas.getContext('experimental-webgl');
                            if (!gl) {
                                isSafe = false; reason = "Perangkat tidak mendukung rendering grafis (Kemungkinan CLI Server).";
                            }
                        } catch (e) {
                            isSafe = false; reason = "Akses mesin grafis (WebGL) diblokir.";
                        }
                    }
                    if (isSafe) {
                        window.location.replace("/secure-grant?redirect=" + encodeURIComponent("${redirectUrl}"));
                    } else {
                        document.getElementById("loading-screen").style.display = "none";
                        document.getElementById("error-box").style.display = "block";
                        document.getElementById("error-reason").innerText = "Alasan: " + reason;
                    }
                }, 2500);
            </script>
        </body>
        </html>
        `;
        return new Response(scannerHTML, { 
          headers: { ...headers, "Content-Type": "text/html;charset=UTF-8" } 
        });
      }
      return new Response(JSON.stringify({ msg: "API Gateway Online", path: url.pathname }), { headers });
    } catch (x) {
      return new Response(JSON.stringify({ error: x.message }), { status: 500, headers });
    }
  }};